package com.pixsimulator.controller;

import com.pixsimulator.model.Usuario;
import com.pixsimulator.model.Transferencia;
import com.pixsimulator.repository.UsuarioRepository;
import com.pixsimulator.repository.TransferenciaRepository;
import com.pixsimulator.service.RecaptchaFraudPreventionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import lombok.Data;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Slf4j
@Controller
@RequiredArgsConstructor
public class TransferenciaController {
    private final UsuarioRepository usuarioRepository;
    private final TransferenciaRepository transferenciaRepository;
    private final RecaptchaFraudPreventionService fraudPreventionService;

    @Value("${google.cloud.site-key}")
    private String recaptchaSiteKey;

    @GetMapping("/transferir")
    public String transferirForm(Model model, Authentication authentication) {
        String email = authentication.getName();
        Usuario usuario = usuarioRepository.findByEmail(email).orElseThrow();
        List<Usuario> usuarios = usuarioRepository.findByIdNot(usuario.getId());
        model.addAttribute("usuarios", usuarios);
        model.addAttribute("recaptchaSiteKey", recaptchaSiteKey);
        return "transferir";
    }

    @PostMapping("/transferir")
    @ResponseBody
    public ResponseEntity<TransferResponse> transferir(@RequestBody TransferRequest request,
                           Authentication authentication,
                           Model model) {
        String email = authentication.getName();
        Usuario remetente = usuarioRepository.findByEmail(email).orElseThrow();
        Usuario destinatario = usuarioRepository.findById(request.getDestinatarioId()).orElseThrow();

        TransferResponse response = new TransferResponse();

        // Validações básicas
        if (request.getValor().compareTo(BigDecimal.ZERO) <= 0) {
            response.setSuccess(false);
            response.setMessage("Valor inválido.");
            return ResponseEntity.badRequest().body(response);
        }
        if (remetente.getSaldo().compareTo(request.getValor()) < 0) {
            response.setSuccess(false);
            response.setMessage("Saldo insuficiente.");
            return ResponseEntity.badRequest().body(response);
        }

        // Avaliação de fraude
        RecaptchaFraudPreventionService.FraudAssessment assessment = null;
        try {
            assessment = fraudPreventionService.assessTransaction(request.getRecaptchaToken(), email, request.getValor());
        } catch (Exception e) {
            log.error("Erro ao chamar o serviço de avaliação de fraude reCAPTCHA: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Erro interno ao verificar a transação. Tente novamente.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
        
        log.debug("Saiu do bloco try-catch do serviço de fraude. Avaliação é null? {}", assessment == null);

        log.info("Avaliação de fraude recebida: Score={}, RiskLevel={}", 
                 assessment != null ? assessment.getScore() : null, 
                 assessment != null ? assessment.getRiskLevel() : "N/A");

        response.setFraudScore(assessment != null ? assessment.getScore() : null);
        response.setFraudRiskLevel(assessment != null ? assessment.getRiskLevel() : "N/A");

        if (assessment == null) {
            log.warn("Não foi possível avaliar o risco da transação");
            response.setSuccess(false);
            response.setMessage("Não foi possível processar a transação neste momento. Tente novamente.");
            // Você pode decidir se isso é um erro do cliente (400) ou do servidor (500)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }

        // Decisão baseada no nível de risco
        if (assessment.isHighRisk()) {
            log.warn("Transação bloqueada por alto risco. Score: {}, Risk: {}", 
                assessment.getScore(), assessment.getTransactionRisk());
            response.setSuccess(false);
            response.setMessage("Transação bloqueada por questões de segurança. Por favor, entre em contato com o suporte.");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        }

        if (assessment.isMediumRisk()) {
            log.info("Transação com risco médio. Score: {}, Risk: {}", 
                assessment.getScore(), assessment.getTransactionRisk());
            // Aqui você poderia implementar uma lógica adicional, como:
            // - Requerer autenticação adicional
            // - Limitar o valor da transação
            // - Registrar para revisão manual
        }

        // Processa a transação
        try {
            // Atualiza saldos
            remetente.setSaldo(remetente.getSaldo().subtract(request.getValor()));
            destinatario.setSaldo(destinatario.getSaldo().add(request.getValor()));
            usuarioRepository.save(remetente);
            usuarioRepository.save(destinatario);

            // Registra transferência
            Transferencia t = new Transferencia();
            t.setRemetente(remetente);
            t.setDestinatario(destinatario);
            t.setValor(request.getValor());
            t.setRiscoFraude(response.getFraudRiskLevel()); // Usa o nível de risco da avaliação
            transferenciaRepository.save(t);

            log.info("Transferência realizada com sucesso. De: {}, Para: {}, Valor: {}, Risco: {}", 
                remetente.getEmail(), destinatario.getEmail(), request.getValor(), response.getFraudRiskLevel());

            response.setSuccess(true);
            response.setMessage("Transferência realizada com sucesso!");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Erro ao processar transferência: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Erro ao processar a transferência. Tente novamente.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @Data
    @AllArgsConstructor
    public static class FraudAssessment {
        // ... existing code ...
    }

    @Data
    static class TransferRequest {
        private Long destinatarioId;
        private BigDecimal valor;
        private String recaptchaToken;
    }
} 