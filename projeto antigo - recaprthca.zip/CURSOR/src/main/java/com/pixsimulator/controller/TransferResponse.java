package com.pixsimulator.controller;

import lombok.Data;

@Data
public class TransferResponse {
    private boolean success;
    private String message;
    private Double fraudScore;
    private String fraudRiskLevel;
} 