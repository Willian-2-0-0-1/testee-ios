package com.pixsimulator.controller;

import com.pixsimulator.model.SimulacaoPix;
import com.pixsimulator.model.Usuario;
import com.pixsimulator.repository.SimulacaoPixRepository;
import com.pixsimulator.repository.UsuarioRepository;
import com.pixsimulator.service.RecaptchaFraudPreventionService;
import lombok.RequiredArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;

import java.math.BigDecimal;
import java.util.List;

@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("/pix")
public class PixController {

    private final SimulacaoPixRepository simulacaoPixRepository;
    private final UsuarioRepository usuarioRepository;
    private final RecaptchaFraudPreventionService recaptchaFraudPreventionService;

    @Value("${google.cloud.site-key}")
    private String recaptchaSiteKey;

    @Data
    public static class PixSimulationResponse {
        private final boolean success;
        private final String message;
        private final Double riskScore;
    }

    @GetMapping
    public String pixForm(Model model, Authentication authentication) {
        String email = authentication.getName();
        Usuario usuario = usuarioRepository.findByEmail(email).orElseThrow();
        List<SimulacaoPix> simulacoes = simulacaoPixRepository.findByUsuario(usuario);
        model.addAttribute("simulacoes", simulacoes);
        model.addAttribute("recaptchaSiteKey", recaptchaSiteKey);

        return "pix";
    }

    @PostMapping("/simular")
    @ResponseBody
    public PixSimulationResponse simularPix(@RequestParam BigDecimal valor,
                                         @RequestParam String destinatario,
                                         @RequestParam String chavePix,
                                         @RequestParam String recaptchaToken,
                                         Authentication authentication) {
        String email = authentication.getName();
        Usuario usuario = usuarioRepository.findByEmail(email).orElseThrow();

        try {
            // 1. Avaliar a transação com reCAPTCHA Fraud Prevention
            RecaptchaFraudPreventionService.FraudAssessment assessment =
                    recaptchaFraudPreventionService.assessTransaction(recaptchaToken, email, valor);

            // Log do score e nível de risco no backend
            log.info("Avaliação de fraude para simulação PIX: Score={}, TransactionRisk={}, RiskLevel={}",
                     assessment != null ? assessment.getScore() : null,
                     assessment != null ? assessment.getTransactionRisk() : null,
                     assessment != null ? assessment.getRiskLevel() : "N/A");

            // Você pode adicionar lógica aqui para negar a simulação com base no score
            // Por exemplo: if (assessment != null && assessment.isHighRisk()) { ... return erro ... }

            // 2. Salvar a simulação
            SimulacaoPix simulacao = new SimulacaoPix();
            simulacao.setValor(valor);
            simulacao.setDestinatario(destinatario);
            simulacao.setChavePix(chavePix);
            simulacao.setUsuario(usuario);

            simulacaoPixRepository.save(simulacao);
            log.info("Simulação PIX salva com sucesso para usuário: {}", email);

            // Retornar resposta de sucesso com o score
            return new PixSimulationResponse(true, "Simulação PIX realizada com sucesso!", assessment != null ? assessment.getScore() : null);

        } catch (Exception e) {
            log.error("Erro ao simular PIX para usuário {}: {}", email, e.getMessage(), e);
            // Retornar resposta de erro com score nulo
            return new PixSimulationResponse(false, "Erro ao realizar simulação PIX.", null);
        }
    }
} 