package com.pixsimulator.controller;

import com.pixsimulator.service.TotpService;
import com.pixsimulator.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

@Controller
@Slf4j
public class MfaController {

    private final TotpService totpService;
    private final UsuarioRepository usuarioRepository;

    @Autowired
    public MfaController(TotpService totpService, UsuarioRepository usuarioRepository) {
        this.totpService = totpService;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping("/verify-mfa")
    public String showMfaVerificationPage(Model model) {
        // Aqui podemos adicionar o email ou username em um campo hidden se necessário
        // model.addAttribute("username", ...);
        return "mfa_verification";
    }

    @PostMapping("/verify-mfa")
    public String verifyMfaCode(@RequestParam("totpCode") String totpCode, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || authentication.getPrincipal() instanceof String) {
            // Usuário não autenticado ou autenticação não é baseada em UserDetails
            return "redirect:/login?error"; // Redireciona de volta para login com erro
        }

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String email = userDetails.getUsername(); // Assumindo que o email é o username

        Optional<com.pixsimulator.model.Usuario> usuarioOptional = usuarioRepository.findByEmail(email);

        if (usuarioOptional.isPresent()) {
            com.pixsimulator.model.Usuario usuario = usuarioOptional.get();
            String secret = usuario.getTotpSecret();

            if (secret != null && totpService.verifyCode(secret, totpCode)) {
                // Código TOTP válido
                // Autenticar completamente o usuário no contexto de segurança
                UsernamePasswordAuthenticationToken finalAuth = new UsernamePasswordAuthenticationToken(
                    userDetails, authentication.getCredentials(), userDetails.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(finalAuth);

                // Redirecionar para a página principal (ou onde o usuário tentou ir originalmente)
                return "redirect:/pix"; // ou "redirect:/" dependendo da sua rota principal
            } else {
                // Código TOTP inválido ou segredo não configurado
                model.addAttribute("error", true);
                return "mfa_verification"; // Volta para a página de verificação com erro
            }
        } else {
            // Usuário não encontrado (situação inesperada após autenticação inicial)
            log.error("Usuário não encontrado no repositório após autenticação inicial: {}", email);
            return "redirect:/login?error";
        }
    }
} 