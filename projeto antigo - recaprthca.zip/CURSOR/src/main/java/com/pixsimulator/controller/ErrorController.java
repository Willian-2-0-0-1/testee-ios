package com.pixsimulator.controller;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Slf4j
@Controller
public class ErrorController implements org.springframework.boot.web.servlet.error.ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");
        
        String errorMessage = "Ocorreu um erro inesperado.";
        
        if (statusCode != null) {
            switch (statusCode) {
                case 404:
                    errorMessage = "Página não encontrada.";
                    break;
                case 403:
                    errorMessage = "Acesso negado.";
                    break;
                case 500:
                    errorMessage = "Erro interno do servidor.";
                    break;
                default:
                    errorMessage = "Erro " + statusCode;
            }
        }

        if (exception != null) {
            log.error("Erro na aplicação: ", exception);
        }

        model.addAttribute("error", errorMessage);
        return "error";
    }
} 