package com.pixsimulator.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

// Importar as classes da biblioteca 
import com.google.cloud.recaptcha.passwordcheck.PasswordCheckResult; // Importar a classe da biblioteca
import com.google.cloud.recaptcha.passwordcheck.PasswordCheckVerification; // Importar a classe da biblioteca
import com.google.cloud.recaptcha.passwordcheck.PasswordCheckVerifier; // Importar a classe da biblioteca
import com.google.protobuf.ByteString; // Necessário para trabalhar com ByteString
import org.bouncycastle.util.encoders.Base64; // Necessário para encodar/decodar Base64

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PasswordLeakCheckService {

    private final String projectId;
    private final String apiKey;
    private final String siteKey;
    private final RestTemplate restTemplate;
    private final PasswordCheckVerifier passwordCheckVerifier; // Instância do verifier

    private static final String RECAPTCHA_API_URL = "https://recaptchaenterprise.googleapis.com/v1/projects/{projectId}/assessments";

    // Construtor para injeção de dependência com @Value nos parâmetros
    public PasswordLeakCheckService(
            @Value("${google.cloud.project-id}") String projectId,
            @Value("${google.cloud.api-key}") String apiKey,
            @Value("${google.cloud.site-key}") String siteKey,
            RestTemplate restTemplate) {
        this.projectId = projectId;
        this.apiKey = apiKey;
        this.siteKey = siteKey;
        this.restTemplate = restTemplate;
        this.passwordCheckVerifier = new PasswordCheckVerifier(); // Inicializa o verifier
        log.info("PasswordLeakCheckService inicializado com projectId: {}, siteKey: {}", projectId, siteKey);
    }

    // Classe interna para o resultado retornado pelo serviço (para o controller)
    @Data
    @AllArgsConstructor
    public static class PasswordCheckResult {
        private final boolean isLeaked;
        private final Double riskScore;
    }

    public PasswordCheckResult checkPassword(String username, String password) {
        log.info("Verificando vazamento de senha para usuário: {}", username);
        Double riskScore = null; // Inicializa riskScore aqui para ter escopo maior
        boolean isLeaked = false; // Inicializa isLeaked aqui para ter escopo maior

        try {
            // 1. Usar a biblioteca auxiliar para criar a verificação (hashing e criptografia)
            PasswordCheckVerification verification = passwordCheckVerifier.createVerification(username, password).get();

            // Extrair os parâmetros gerados (hashes e dados criptografados)
            String lookupHashPrefix = Base64.toBase64String(verification.getLookupHashPrefix());
            String encryptedUserCredentialsHash = Base64.toBase64String(verification.getEncryptedUserCredentialsHash());

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("x-goog-api-key", apiKey);
            log.debug("Headers configurados: {}", headers);

            // 2. Preparar o corpo da requisição para a API do Google Cloud
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("event", Map.of(
                "siteKey", siteKey,
                "token", "dummy-token", // Usar um token real do frontend se aplicável a essa ação
                "expectedAction", "password_check"
            ));
            // Incluir os parâmetros gerados pela biblioteca auxiliar
            requestBody.put("privatePasswordLeakVerification", Map.of(
                "lookupHashPrefix", lookupHashPrefix,
                "encryptedUserCredentialsHash", encryptedUserCredentialsHash
            ));

            log.debug("Request body preparado: {}", requestBody);

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            log.info("Enviando requisição para verificação de senha vazada");

            Map<String, Object> response = restTemplate.postForObject(
                RECAPTCHA_API_URL,
                request,
                Map.class,
                projectId
            );
            log.debug("Resposta recebida: {}", response);

            if (response != null) {
                // Verifica o riskAnalysis.score (obtido diretamente da resposta da API)
                Map<String, Object> riskAnalysis = (Map<String, Object>) response.get("riskAnalysis");
                if (riskAnalysis != null && riskAnalysis.containsKey("score")) {
                     Object scoreObject = riskAnalysis.get("score");
                     if (scoreObject instanceof Number) {
                        riskScore = ((Number) scoreObject).doubleValue();
                        log.info("Score de risco da verificação de senha: {}", riskScore);
                     } else {
                         log.warn("Score de risco não é um número: {}", scoreObject);
                     }
                } else {
                    log.warn("Resposta não contém riskAnalysis ou score");
                }

                // 3. Processar a resposta e verificar vazamento localmente com a biblioteca auxiliar
                if (response.containsKey("privatePasswordLeakVerification")) {
                    Map<String, Object> passwordLeakVerificationResponse = (Map<String, Object>) response.get("privatePasswordLeakVerification");

                    String reencryptedUserCredentialsHashBase64 = (String) passwordLeakVerificationResponse.get("reencryptedUserCredentialsHash");
                    List<String> encryptedLeakMatchPrefixesBase64 = (List<String>) passwordLeakVerificationResponse.get("encryptedLeakMatchPrefixes");

                    // Converter Base64 de volta para byte[]
                    byte[] reencryptedUserCredentialsHash = Base64.decode(reencryptedUserCredentialsHashBase64);
                    List<byte[]> encryptedLeakMatchPrefixes = encryptedLeakMatchPrefixesBase64.stream()
                            .map(Base64::decode)
                            .collect(Collectors.toList());

                    // Usar a biblioteca auxiliar para verificar se houve vazamento
                    com.google.cloud.recaptcha.passwordcheck.PasswordCheckResult verificationResult = passwordCheckVerifier.verify(
                            verification,
                            reencryptedUserCredentialsHash,
                            encryptedLeakMatchPrefixes
                    ).get();

                    isLeaked = verificationResult.areCredentialsLeaked(); // Usar o método da classe da biblioteca
                    log.info("Resultado da verificação de senha vazada para {}: {}", username, isLeaked ? "SENHA VAZADA" : "Senha segura");

                } else {
                     log.warn("Resposta não contém privatePasswordLeakVerification");
                }

            }

            // Retorna o resultado usando a classe interna local
            return new PasswordCheckResult(isLeaked, riskScore);
        } catch (ExecutionException | InterruptedException e) {
             log.error("Erro de execução ou interrupção ao verificar vazamento de senha para {}: {}", username, e.getMessage(), e);
             // Em caso de erro grave na comunicação, pode ser mais seguro considerar como vazado ou negar o acesso.
             // Por enquanto, retornamos false/null para não bloquear o fluxo de login/registro em caso de falha da API.
             return new PasswordCheckResult(false, null); // Retorna falso/null em caso de erro
        } catch (Exception e) {
            log.error("Erro geral ao verificar vazamento de senha para {}: {}", username, e.getMessage(), e);
            // Em caso de erro geral, também retornamos false/null.
            return new PasswordCheckResult(false, null); // Retorna falso/null em caso de erro
        }
    }
} 