package com.pixsimulator.model;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "transferencias")
public class Transferencia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "remetente_id", nullable = false)
    private Usuario remetente;

    @ManyToOne
    @JoinColumn(name = "destinatario_id", nullable = false)
    private Usuario destinatario;

    @Column(nullable = false)
    private BigDecimal valor;

    @Column(name = "data_transferencia", nullable = false)
    private LocalDateTime dataTransferencia = LocalDateTime.now();

    @Column(name = "risco_fraude")
    private String riscoFraude;

    @PrePersist
    protected void onCreate() {
        dataTransferencia = LocalDateTime.now();
    }
} 