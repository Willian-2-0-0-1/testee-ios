package com.pixsimulator.model;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "simulacoes_pix")
public class SimulacaoPix {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private BigDecimal valor;

    @Column(nullable = false)
    private String destinatario;

    @Column(nullable = false)
    private String chavePix;

    @Column(nullable = false)
    private LocalDateTime dataSimulacao;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @PrePersist
    protected void onCreate() {
        dataSimulacao = LocalDateTime.now();
    }
} 