package com.pixsimulator.repository;

import com.pixsimulator.model.SimulacaoPix;
import com.pixsimulator.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SimulacaoPixRepository extends JpaRepository<SimulacaoPix, Long> {
    List<SimulacaoPix> findByUsuario(Usuario usuario);
} 