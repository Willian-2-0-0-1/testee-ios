package com.pixsimulator.controller;

import com.pixsimulator.model.Usuario;
import com.pixsimulator.repository.UsuarioRepository;
import com.pixsimulator.service.PasswordLeakCheckService;
import lombok.RequiredArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import lombok.extern.slf4j.Slf4j;
import java.math.BigDecimal;
import com.pixsimulator.service.PasswordLeakCheckService.PasswordCheckResult;

@Slf4j
@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final PasswordLeakCheckService passwordLeakCheckService;

    @Value("${google.cloud.site-key}")
    private String recaptchaSiteKey;

    @Data
    public static class RegisterRequest {
        private String nome;
        private String email;
        private String senha;
    }

    @Data
    public static class LoginRequest {
        private String username;
        private String password;
    }

    @Data
    public static class PasswordCheckResponse {
        private final boolean isLeaked;
        private final Double riskScore;
        private final String message;
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("recaptchaSiteKey", recaptchaSiteKey);
        return "login";
    }

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("recaptchaSiteKey", recaptchaSiteKey);
        return "register";
    }

    @PostMapping("/register")
    @ResponseBody
    public PasswordCheckResponse register(@RequestBody RegisterRequest registerRequest) {
        log.info("Tentando registrar usuário com email: {}", registerRequest.getEmail());
        
        if (usuarioRepository.existsByEmail(registerRequest.getEmail())) {
            log.warn("Email já cadastrado: {}", registerRequest.getEmail());
            return new PasswordCheckResponse(false, null, "Email já cadastrado");
        }

        PasswordCheckResult checkResult = passwordLeakCheckService.checkPassword(registerRequest.getEmail(), registerRequest.getSenha());
        
        if (checkResult.isLeaked()) {
            log.warn("Senha vazada detectada para o email: {}", registerRequest.getEmail());
            return new PasswordCheckResponse(true, checkResult.getRiskScore(), 
                "Esta senha foi comprometida em vazamentos anteriores. Por favor, escolha outra senha.");
        }

        try {
            Usuario usuario = new Usuario();
            usuario.setNome(registerRequest.getNome());
            usuario.setEmail(registerRequest.getEmail());
            usuario.setSenha(passwordEncoder.encode(registerRequest.getSenha()));
            usuario.setSaldo(new BigDecimal("100.00"));
            
            Usuario savedUser = usuarioRepository.save(usuario);
            log.info("Usuário registrado com sucesso. ID: {}", savedUser.getId());
            
            return new PasswordCheckResponse(false, checkResult.getRiskScore(), "Usuário registrado com sucesso!");
        } catch (Exception e) {
            log.error("Erro ao registrar usuário: {}", e.getMessage(), e);
            return new PasswordCheckResponse(false, checkResult.getRiskScore(), 
                "Erro ao registrar usuário. Tente novamente.");
        }
    }
} 