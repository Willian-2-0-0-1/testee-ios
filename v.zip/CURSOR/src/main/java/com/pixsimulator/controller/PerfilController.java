package com.pixsimulator.controller;

import com.pixsimulator.model.Usuario;
import com.pixsimulator.model.Transferencia;
import com.pixsimulator.repository.UsuarioRepository;
import com.pixsimulator.repository.TransferenciaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class PerfilController {
    private final UsuarioRepository usuarioRepository;
    private final TransferenciaRepository transferenciaRepository;
    private final PasswordEncoder passwordEncoder;

    @GetMapping("/perfil")
    public String perfil(Model model, Authentication authentication) {
        String email = authentication.getName();
        Usuario usuario = usuarioRepository.findByEmail(email).orElseThrow();
        List<Transferencia> transferencias = transferenciaRepository.findByRemetenteOrDestinatario(usuario, usuario);
        model.addAttribute("usuario", usuario);
        model.addAttribute("transferencias", transferencias);
        return "perfil";
    }

    @GetMapping("/perfil/editar")
    public String editarPerfilForm(Model model, Authentication authentication) {
        String email = authentication.getName();
        Usuario usuario = usuarioRepository.findByEmail(email).orElseThrow();
        model.addAttribute("usuario", usuario);
        return "editar_perfil";
    }

    @PostMapping("/perfil/editar")
    public String editarPerfil(@RequestParam String nome,
                               @RequestParam String email,
                               @RequestParam(required = false) String senhaAntiga,
                               @RequestParam(required = false) String senhaNova,
                               Authentication authentication,
                               Model model) {
        String currentEmail = authentication.getName();
        Usuario usuario = usuarioRepository.findByEmail(currentEmail).orElseThrow();
        
        // Verifica se o email já está em uso por outro usuário
        if (!currentEmail.equals(email) && usuarioRepository.existsByEmail(email)) {
            model.addAttribute("error", "Este email já está em uso por outro usuário.");
            model.addAttribute("usuario", usuario);
            return "editar_perfil";
        }

        usuario.setNome(nome);
        usuario.setEmail(email);

        // Se uma nova senha foi fornecida, valida a senha antiga
        if (senhaNova != null && !senhaNova.isBlank()) {
            if (senhaAntiga == null || senhaAntiga.isBlank()) {
                model.addAttribute("error", "A senha atual é obrigatória para alterar a senha.");
                model.addAttribute("usuario", usuario);
                return "editar_perfil";
            }

            if (!passwordEncoder.matches(senhaAntiga, usuario.getSenha())) {
                model.addAttribute("error", "Senha atual incorreta.");
                model.addAttribute("usuario", usuario);
                return "editar_perfil";
            }

            usuario.setSenha(passwordEncoder.encode(senhaNova));
        }

        usuarioRepository.save(usuario);
        model.addAttribute("success", "Dados atualizados com sucesso!");
        return "redirect:/perfil";
    }

    @GetMapping("/perfil/excluir")
    public String excluirPerfilConfirm() {
        return "excluir_perfil";
    }

    @PostMapping("/perfil/excluir")
    public String excluirPerfil(Authentication authentication) {
        String email = authentication.getName();
        Usuario usuario = usuarioRepository.findByEmail(email).orElseThrow();
        usuarioRepository.delete(usuario);
        return "redirect:/logout";
    }
} 