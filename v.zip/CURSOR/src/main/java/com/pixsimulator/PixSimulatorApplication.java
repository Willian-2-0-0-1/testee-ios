package com.pixsimulator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PixSimulatorApplication {
    public static void main(String[] args) {
        SpringApplication.run(PixSimulatorApplication.class, args);
    }
} 