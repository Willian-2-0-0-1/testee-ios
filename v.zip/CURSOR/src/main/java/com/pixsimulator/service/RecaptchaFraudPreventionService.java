package com.pixsimulator.service;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class RecaptchaFraudPreventionService {

    private final RestTemplate restTemplate;

    @Value("${google.cloud.site-key}")
    private String siteKey;

    @Value("${google.cloud.api-key}")
    private String apiKey;

    @Value("${google.cloud.project-id}")
    private String projectId;

    @Value("${google.cloud.site-key}")
    private String recaptchaKey;

    private static final String ASSESSMENT_URL = "https://recaptchaenterprise.googleapis.com/v1/projects/{projectId}/assessments?key={apiKey}";
    
    // Níveis de tolerância
    private static final double RISK_THRESHOLD_LOW = 0.5;  // 5% falsos positivos
    private static final double RISK_THRESHOLD_MEDIUM = 0.7; // 1% falsos positivos
    private static final double RISK_THRESHOLD_HIGH = 0.9;   // 0.1% falsos positivos

    public FraudAssessment assessTransaction(String token, String email, BigDecimal valor) {
        // Lógica original comentada para testes
        /*
        try {
            String url = ASSESSMENT_URL.replace("{projectId}", projectId).replace("{apiKey}", apiKey);
            
            Map<String, Object> requestBody = new HashMap<>();
            Map<String, Object> event = new HashMap<>();
            event.put("token", token);
            event.put("siteKey", recaptchaKey);
            event.put("expectedAction", "transferencia_pix");
            
            Map<String, Object> transactionData = new HashMap<>();
            transactionData.put("transaction_id", UUID.randomUUID().toString());
            transactionData.put("payment_method", "pix");
            transactionData.put("value", valor.doubleValue());
            transactionData.put("currency_code", "BRL");
            
            Map<String, Object> user = new HashMap<>();
            user.put("email", email);
            transactionData.put("user", user);
            
            event.put("transactionData", transactionData);
            requestBody.put("event", event);

            log.debug("Enviando requisição para avaliação de fraude: {}", requestBody);
            
            ResponseEntity<Map> response = restTemplate.postForEntity(url, requestBody, Map.class);
            log.debug("Resposta recebida: {}", response.getBody());

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                @SuppressWarnings("unchecked")
                Map<String, Object> body = (Map<String, Object>) response.getBody();
                Object riskAnalysisObj = body.get("riskAnalysis");
                Object fraudPreventionObj = body.get("fraudPreventionAssessment");
                
                if (riskAnalysisObj instanceof Map && fraudPreventionObj instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> riskAnalysis = (Map<String, Object>) riskAnalysisObj;
                    @SuppressWarnings("unchecked")
                    Map<String, Object> fraudPrevention = (Map<String, Object>) fraudPreventionObj;
                    
                    if (riskAnalysis != null && fraudPrevention != null) {
                        double score = ((Number) riskAnalysis.get("score")).doubleValue();
                        double transactionRisk = ((Number) fraudPrevention.get("transactionRisk")).doubleValue();
                        
                        String riskLevel;
                        if (transactionRisk >= RISK_THRESHOLD_HIGH) {
                            riskLevel = "ALTO";
                        } else if (transactionRisk >= RISK_THRESHOLD_MEDIUM) {
                            riskLevel = "MÉDIO";
                        } else if (transactionRisk >= RISK_THRESHOLD_LOW) {
                            riskLevel = "BAIXO";
                        } else {
                            riskLevel = "MÍNIMO";
                        }
                        
                        return new FraudAssessment(score, transactionRisk, riskLevel);
                    }
                }
            }
            
            log.warn("Resposta inválida do serviço de avaliação de fraude: {}", response.getBody());
            return null;
            
        } catch (Exception e) {
            log.error("Erro ao avaliar transação: {}", e.getMessage(), e);
            throw new RuntimeException("Erro ao avaliar risco da transação", e);
        }
        */

        // Lógica forçada para testes - sempre retorna risco ALTO para forçar MFA
        log.info("Usando lógica forçada para testes - Sempre retornando risco ALTO");
        return new FraudAssessment(0.1, 0.95, "ALTO");
    }

    @lombok.Data
    @AllArgsConstructor
    public static class FraudAssessment {
        private final double score;
        private final double transactionRisk;
        private final String riskLevel;
        
        public boolean isHighRisk() {
            return transactionRisk >= RISK_THRESHOLD_HIGH;
        }
        
        public boolean isMediumRisk() {
            return transactionRisk >= RISK_THRESHOLD_MEDIUM && transactionRisk < RISK_THRESHOLD_HIGH;
        }
        
        public boolean isLowRisk() {
            return transactionRisk >= RISK_THRESHOLD_LOW && transactionRisk < RISK_THRESHOLD_MEDIUM;
        }
        
        public boolean isMinimalRisk() {
            return transactionRisk < RISK_THRESHOLD_LOW;
        }
    }
} 