
import UIKit

class TelaAPIViewController: UIViewController {
    let label = UILabel()
    let botao = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "API Mocky"

        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false

        botao.setTitle("Buscar dados", for: .normal)
        botao.addTarget(self, action: #selector(fetchAPI), for: .touchUpInside)
        botao.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(label)
        view.addSubview(botao)

        NSLayoutConstraint.activate([
            botao.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            botao.centerYAnchor.constraint(equalTo: view.centerYAnchor),

            label.topAnchor.constraint(equalTo: botao.bottomAnchor, constant: 20),
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    @objc func fetchAPI() {
        guard let url = URL(string: "https://run.mocky.io/v3/1df9336d-0289-4bfa-8b91-29e424e6b7e9") else { return }
        let task = URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let texto = String(data: data, encoding: .utf8) {
                DispatchQueue.main.async {
                    self.label.text = texto
                }
            }
        }
        task.resume()
    }
}
