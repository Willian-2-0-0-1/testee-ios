Abra o Xcode, crie um novo projeto chamado 'AppsecBradesco' com UIKit + Swift, e arraste os arquivos dessa pasta para dentro do projeto.
