
import UIKit

class TelaInicialViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        configurarCabecalho()
        configurarBotoes()
    }
    
    func configurarCabecalho() {
        let cabecalho = UILabel()
        cabecalho.text = "Appsec Bradesco"
        cabecalho.backgroundColor = UIColor(red: 139/255, green: 0, blue: 0, alpha: 1)
        cabecalho.textColor = .white
        cabecalho.font = UIFont.boldSystemFont(ofSize: 20)
        cabecalho.textAlignment = .left
        cabecalho.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(cabecalho)
        
        NSLayoutConstraint.activate([
            cabecalho.topAnchor.constraint(equalTo: view.topAnchor),
            cabecalho.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            cabecalho.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            cabecalho.heightAnchor.constraint(equalToConstant: 60)
        ])
    }
    
    func configurarBotoes() {
        let titulos = ["AUSÊNCIA DO SSL PINNING", "ARMAZENAMENTO INSEGURO", "INJEÇÃO DE DADOS"]
        let acoes: [Selector] = [#selector(abrirSSL), #selector(abrirStorage), #selector(abrirInjecao)]
        
        var botoes: [UIButton] = []
        
        for i in 0..<titulos.count {
            let botao = UIButton(type: .system)
            botao.setTitle(titulos[i], for: .normal)
            botao.setTitleColor(.white, for: .normal)
            botao.backgroundColor = UIColor(red: 139/255, green: 0, blue: 0, alpha: 1)
            botao.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
            botao.layer.cornerRadius = 6
            botao.translatesAutoresizingMaskIntoConstraints = false
            botao.addTarget(self, action: acoes[i], for: .touchUpInside)
            botoes.append(botao)
            view.addSubview(botao)
        }
        
        NSLayoutConstraint.activate([
            botoes[0].centerXAnchor.constraint(equalTo: view.centerXAnchor),
            botoes[0].topAnchor.constraint(equalTo: view.centerYAnchor, constant: -60),
            botoes[0].widthAnchor.constraint(equalToConstant: 280),
            botoes[0].heightAnchor.constraint(equalToConstant: 40),
            
            botoes[1].centerXAnchor.constraint(equalTo: view.centerXAnchor),
            botoes[1].topAnchor.constraint(equalTo: botoes[0].bottomAnchor, constant: 16),
            botoes[1].widthAnchor.constraint(equalTo: botoes[0].widthAnchor),
            botoes[1].heightAnchor.constraint(equalTo: botoes[0].heightAnchor),
            
            botoes[2].centerXAnchor.constraint(equalTo: view.centerXAnchor),
            botoes[2].topAnchor.constraint(equalTo: botoes[1].bottomAnchor, constant: 16),
            botoes[2].widthAnchor.constraint(equalTo: botoes[0].widthAnchor),
            botoes[2].heightAnchor.constraint(equalTo: botoes[0].heightAnchor)
        ])
    }
    
    @objc func abrirSSL() {
        let tela = TelaAPIViewController()
        navigationController?.pushViewController(tela, animated: true)
    }
    
    @objc func abrirStorage() {
        let tela = TelaComentariosViewController()
        navigationController?.pushViewController(tela, animated: true)
    }
    
    @objc func abrirInjecao() {
        let tela = TelaInjecaoViewController()
        navigationController?.pushViewController(tela, animated: true)
    }
}
