
import UIKit

class TelaInjecaoViewController: UIViewController {
    
    let campoUsuario = UITextField()
    let botaoBuscar = UIButton(type: .system)
    let resultadoLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Injeção de Dados"
        view.backgroundColor = .white
        
        campoUsuario.placeholder = "Digite o nome do usuário"
        campoUsuario.borderStyle = .roundedRect
        campoUsuario.translatesAutoresizingMaskIntoConstraints = false
        
        botaoBuscar.setTitle("Buscar", for: .normal)
        botaoBuscar.setTitleColor(.white, for: .normal)
        botaoBuscar.backgroundColor = UIColor(red: 139/255, green: 0, blue: 0, alpha: 1)
        botaoBuscar.layer.cornerRadius = 5
        botaoBuscar.translatesAutoresizingMaskIntoConstraints = false
        botaoBuscar.addTarget(self, action: #selector(buscarUsuario), for: .touchUpInside)
        
        resultadoLabel.numberOfLines = 0
        resultadoLabel.textAlignment = .left
        resultadoLabel.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(campoUsuario)
        view.addSubview(botaoBuscar)
        view.addSubview(resultadoLabel)
        
        NSLayoutConstraint.activate([
            campoUsuario.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 32),
            campoUsuario.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            campoUsuario.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            campoUsuario.heightAnchor.constraint(equalToConstant: 40),
            
            botaoBuscar.topAnchor.constraint(equalTo: campoUsuario.bottomAnchor, constant: 20),
            botaoBuscar.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            botaoBuscar.widthAnchor.constraint(equalToConstant: 100),
            botaoBuscar.heightAnchor.constraint(equalToConstant: 40),
            
            resultadoLabel.topAnchor.constraint(equalTo: botaoBuscar.bottomAnchor, constant: 30),
            resultadoLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            resultadoLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
        ])
    }
    
    @objc func buscarUsuario() {
        let entradaUsuario = campoUsuario.text ?? ""
        let query = "SELECT * FROM usuarios WHERE nome = '\(entradaUsuario)'"
        var resultado = "Executando query:
\(query)

"
        
        if entradaUsuario.contains("' OR '1'='1") {
            resultado += "🛑 Resultado: TODOS os usuários foram retornados (vulnerável à injeção)"
        } else if entradaUsuario.lowercased().contains("drop") {
            resultado += "💥 Cuidado! Comando perigoso detectado: possível tentativa de deleção de tabela"
        } else {
            resultado += "✅ Nenhum resultado encontrado (consulta segura)"
        }
        
        resultadoLabel.text = resultado
    }
}
