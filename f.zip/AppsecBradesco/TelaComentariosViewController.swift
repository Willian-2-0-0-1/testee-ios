
import UIKit
import CoreData

class TelaComentariosViewController: UIViewController, UITableViewDataSource {
    
    let campoComentario = UITextField()
    let botaoEnviar = UIButton(type: .system)
    let tabela = UITableView()
    var comentarios: [Comentario] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Comentários Inseguros"

        configurarUI()
        carregarComentarios()
    }

    func configurarUI() {
        campoComentario.placeholder = "Digite seu comentário"
        campoComentario.borderStyle = .roundedRect
        campoComentario.translatesAutoresizingMaskIntoConstraints = false
        
        botaoEnviar.setTitle("Salvar", for: .normal)
        botaoEnviar.setTitleColor(.white, for: .normal)
        botaoEnviar.backgroundColor = UIColor(red: 139/255, green: 0, blue: 0, alpha: 1)
        botaoEnviar.layer.cornerRadius = 5
        botaoEnviar.translatesAutoresizingMaskIntoConstraints = false
        botaoEnviar.addTarget(self, action: #selector(salvar), for: .touchUpInside)
        
        tabela.dataSource = self
        tabela.register(UITableViewCell.self, forCellReuseIdentifier: "celula")
        tabela.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(campoComentario)
        view.addSubview(botaoEnviar)
        view.addSubview(tabela)
        
        NSLayoutConstraint.activate([
            campoComentario.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            campoComentario.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            campoComentario.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            campoComentario.heightAnchor.constraint(equalToConstant: 40),
            
            botaoEnviar.topAnchor.constraint(equalTo: campoComentario.bottomAnchor, constant: 12),
            botaoEnviar.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            botaoEnviar.heightAnchor.constraint(equalToConstant: 40),
            botaoEnviar.widthAnchor.constraint(equalToConstant: 120),
            
            tabela.topAnchor.constraint(equalTo: botaoEnviar.bottomAnchor, constant: 16),
            tabela.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tabela.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tabela.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    func carregarComentarios() {
        let req: NSFetchRequest<Comentario> = Comentario.fetchRequest()
        comentarios = (try? CoreDataStack.shared.context.fetch(req)) ?? []
        tabela.reloadData()
    }

    @objc func salvar() {
        let novo = Comentario(context: CoreDataStack.shared.context)
        novo.texto = campoComentario.text
        novo.data = Date()
        
        CoreDataStack.shared.salvar()
        carregarComentarios()
        campoComentario.text = ""
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return comentarios.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let comentario = comentarios[indexPath.row]
        let celula = tableView.dequeueReusableCell(withIdentifier: "celula", for: indexPath)
        celula.textLabel?.text = comentario.texto
        return celula
    }
}
