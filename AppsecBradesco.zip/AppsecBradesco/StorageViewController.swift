import UIKit

class StorageViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        let userDefaults = UserDefaults.standard
        userDefaults.set("senha123", forKey: "user_password")

        if let senha = userDefaults.string(forKey: "user_password") {
            print("Senha armazenada: \(senha)")
        }
    }
}
