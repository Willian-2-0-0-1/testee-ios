import UIKit

class InjectionViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let input = "'; DROP TABLE users;--"
        let query = "SELECT * FROM users WHERE username = '\(input)'"
        print("Executando: \(query)")
    }
}
