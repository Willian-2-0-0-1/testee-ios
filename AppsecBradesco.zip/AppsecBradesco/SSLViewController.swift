import UIKit

class SSLViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        let url = URL(string: "https://self-signed.badssl.com/")!
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                print("Dados recebidos: \(data)")
            } else {
                print("Erro: \(error?.localizedDescription ?? "desconhecido")")
            }
        }
        task.resume()
    }
}
